import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

@RunWith(JUnit4.class)
public class BuildGraphTest {

    @Test
    public void validGraphTest() {
        List<Device> expected = new ArrayList<Device>();
        boolean trueBoolean = true;
        boolean falseBoolean = false;
        Device device1 = new Device("EWR-1234","1/4/2022","Encost Router 360","Router","WKO-1234","-",true,true); 
        Device device2 = new Device("ELB-4567","1/4/2022","Encost Smart Bulb B22 (multi colour)","Light Bulb","WKO-1236","EWR-1234",false,true);
        Device device3 = new Device("EK-9867","7/5/2023","Encost Smart Jug Kettle","Kettle","WKO-1237","EWR-1234",false,true);
        Device device4 = new Device("EHC-2468","7/5/2022","Encost Smart Hub","Hub/Controller","WKO-1235","EWR-1234",true,true);
        // Insert devices into list.
        expected.add(device1);
        expected.add(device2);
        expected.add(device3);
        expected.add(device4);

        // ESGP is a guideline for the ESGP naming conventions and was required to make for testing
        Encost project = new Encost();
        GraphClass testGraph = new GraphClass();

        // Collect the devices which are graphed, this should be the same as the expected list
        File dataset = new File("Encost_Smart_Homes_Dataset_Small.csv");
        project.readDataset(dataset, testGraph);
        List<Device> actual = testGraph.getDevices();

        assertArrayEquals(expected.toArray(), actual.toArray());
    }

    @Test
    public void invalidGraphTest() {
        List<Device> expected = new ArrayList<Device>();
        // ESGP is a guideline for the ESGP naming conventions and was required to make for testing
        Encost project = new Encost();
        GraphClass testGraph = new GraphClass();

        // Collect the devices which are graphed, this should be the same as the expected list
        File dataset = new File("invalidTest.csv");
        project.readDataset(dataset, testGraph);
        List<Device> actual = testGraph.getDevices();

        assertArrayEquals(expected.toArray(), actual.toArray());
    }
}
